# HOTEL GMAO PRO
واجهة أولية لموقع إدارة الصيانة الفندقية (عربي/فرنسي).
## تشغيل محلي
افتح `www/index.html` في المتصفح.
## تحويل إلى Android (يتطلب بيئة Node/Android)
```bash
npm install
npx cap add android
npx cap sync android
```
ثم افتح مشروع android في Android Studio وابنِ APK.
